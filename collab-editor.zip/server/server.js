const express = require("express");
const http = require("http");
const mongoose = require("mongoose");
const cors = require("cors");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "http://localhost:3000",
    methods: ["GET", "POST"]
  }
});

mongoose.connect("mongodb://127.0.0.1:27017/collab-docs", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const Document = mongoose.model("Document", new mongoose.Schema({
  _id: String,
  content: Object,
}));

io.on("connection", socket => {
  socket.on("get-document", async docId => {
    const doc = await Document.findById(docId) || await Document.create({ _id: docId, content: "" });
    socket.join(docId);
    socket.emit("load-document", doc.content);

    socket.on("send-changes", delta => {
      socket.broadcast.to(docId).emit("receive-changes", delta);
    });

    socket.on("save-document", async data => {
      await Document.findByIdAndUpdate(docId, { content: data });
    });
  });
});

server.listen(3001, () => console.log("Server running on port 3001"));
