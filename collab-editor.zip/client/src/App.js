import React from "react";
import Editor from "./Editor";

function App() {
  return <Editor />;
}

export default App;
