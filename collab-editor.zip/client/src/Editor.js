import React, { useEffect, useRef } from 'react';
import Quill from 'quill';
import { io } from 'socket.io-client';
import 'quill/dist/quill.snow.css';

const SAVE_INTERVAL = 2000;

const Editor = () => {
  const wrapperRef = useRef();
  const socketRef = useRef();
  const quillRef = useRef();

  useEffect(() => {
    const editorContainer = document.createElement("div");
    wrapperRef.current.append(editorContainer);
    const quill = new Quill(editorContainer, { theme: "snow" });
    quill.disable();
    quill.setText("Loading...");
    quillRef.current = quill;

    const socket = io("http://localhost:3001");
    socketRef.current = socket;

    const docId = "example-doc";
    socket.once("load-document", document => {
      quill.setContents(document);
      quill.enable();
    });

    socket.emit("get-document", docId);

    quill.on("text-change", (delta, oldDelta, source) => {
      if (source !== "user") return;
      socket.emit("send-changes", delta);
    });

    socket.on("receive-changes", delta => {
      quill.updateContents(delta);
    });

    const interval = setInterval(() => {
      socket.emit("save-document", quill.getContents());
    }, SAVE_INTERVAL);

    return () => {
      socket.disconnect();
      clearInterval(interval);
    };
  }, []);

  return <div className="editor" ref={wrapperRef} style={{ height: "100vh" }} />;
};

export default Editor;
